To run the KNN algorithm
Be sure to have the irisdataset.txt file in the directory that youre running the program from

You will be propted to enter a kValue;

	Enter kValue
	(user value)


Then enter the values for each feature of the plant

	Enter the sepal length in cm: (user value)
	Enter the sepal width in cm: (user value)
	Enter the petal length in cm: (user value)
	Enter petal width in cm: (user value)

The results will show up depending on the value of your k.

Example: k = 2

	Neightbor 1 (closest): (number of item in the dataset, name of the plant)
	Neighbor 2 :(number of item in the dataset, name of the plant )


To run the LinearRegression algorithm 
make sure that the linearRegression.txt file is in the directory that youre running the program from 

When you run the program it will inform you of when the training will be done

	Done training 
	Enter the number of Cylinders: User Input
	Enter the Displacement: User Input 
	Enter the Horsepower: User Input
	Enter the Weight: User Input
	Enter the Acceleraration: User Input

After youve entered the values you will be presented
with the MPG prediction 
	
	MPG prediction:(prediction value)
